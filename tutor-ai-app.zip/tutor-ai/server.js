'use strict';
// Tutor AI server — Node 18+, koi npm package nahi chahiye.
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const { spawn, spawnSync } = require('child_process');

try { fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split('\n').forEach(l => {
  const m = l.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
  if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
}); } catch {}
const E = process.env, G = 'https://generativelanguage.googleapis.com/v1beta';
let thinking = null; try { if (E.DEEP_THINKING_CONFIG) thinking = JSON.parse(E.DEEP_THINKING_CONFIG); } catch {}
const C = {
  port: +E.PORT || 3000, token: E.ACCESS_TOKEN || '',
  chat: E.CHAT_PROVIDER || 'gemini', img: E.IMAGE_PROVIDER || 'gemini',
  chatModel: E.CHAT_MODEL || 'gemini-2.5-flash', deepModel: E.DEEP_MODEL || E.CHAT_MODEL || 'gemini-2.5-pro',
  imgModel: E.IMAGE_MODEL || 'gemini-2.5-flash-image', vidModel: E.VIDEO_MODEL || 'veo-3.1-generate-preview',
  gKey: E.GEMINI_API_KEY || '', oaKey: E.OPENAI_API_KEY || '',
  oaBase: (E.OPENAI_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, ''),
  sceneSec: +E.SCENE_SECONDS || 8, maxScenes: +E.MAX_SCENES || 60, maxJobs: +E.MAX_JOBS || 2, thinking
};
let SYS = 'You are Tutor AI. Reply in the user\'s language. Answer first, be honest, never invent facts.';
try { SYS = fs.readFileSync(path.join(__dirname, 'system-prompt.txt'), 'utf8'); } catch {}
const HAS_FF = spawnSync('ffmpeg', ['-version']).status === 0;
const DIR = path.join(__dirname, 'jobs'); fs.mkdirSync(DIR, { recursive: true });

const send = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); };
const readBody = (req, max) => new Promise((ok, no) => {
  let n = 0; const a = [];
  req.on('data', c => { n += c.length; if (n > max) { no(new Error('Request bohat bari hai')); req.destroy(); return; } a.push(c); });
  req.on('end', () => { try { ok(JSON.parse(Buffer.concat(a).toString() || '{}')); } catch (e) { no(e); } });
  req.on('error', no);
});
const gfetch = (p, init = {}) => { if (!C.gKey) throw new Error('GEMINI_API_KEY .env file mein set karein.'); return fetch(p.startsWith('http') ? p : G + p,
  { ...init, headers: { 'x-goog-api-key': C.gKey, 'Content-Type': 'application/json', ...(init.headers || {}) } }); };
const ff = args => new Promise(ok => { const p = spawn('ffmpeg', args, { stdio: 'ignore' }); p.on('error', () => ok(false)); p.on('close', c => ok(c === 0)); });
const rj = async r => { const t = await r.text(); try { return JSON.parse(t); } catch { throw new Error('Server ka jawab ' + r.status + ': ' + t.slice(0, 150)); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const cleanJSON = t => JSON.parse(String(t).replace(/```json|```/g, '').trim());

async function* sse(r) {
  const dec = new TextDecoder(); let buf = '';
  for await (const ch of r.body) {
    buf += dec.decode(ch, { stream: true }); let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
      if (line.startsWith('data:')) { const d = line.slice(5).trim(); if (d && d !== '[DONE]') yield d; }
    }
  }
}

/* ---------- CHAT (text + tasveer samajhna + deep thinking) ---------- */
async function* chatStream(msgs, images, deep) {
  const model = deep ? C.deepModel : C.chatModel;
  if (C.chat === 'openai') {                     // OpenAI, Groq, OpenRouter, Ollama, LM Studio, vLLM...
    const m = [{ role: 'system', content: SYS }, ...msgs.map(x => ({ role: x.r === 'me' ? 'user' : 'assistant', content: x.c }))];
    if (images.length) { const l = m[m.length - 1]; l.content = [{ type: 'text', text: l.content }, ...images.map(i => ({ type: 'image_url', image_url: { url: `data:${i.mime};base64,${i.data}` } }))]; }
    const r = await fetch(C.oaBase + '/chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + C.oaKey }, body: JSON.stringify({ model, messages: m, stream: true }) });
    if (!r.ok) throw new Error('chat ' + r.status + ' ' + (await r.text()).slice(0, 300));
    for await (const d of sse(r)) { const t = JSON.parse(d).choices?.[0]?.delta?.content; if (t) yield t; }
    return;
  }
  const contents = msgs.map(x => ({ role: x.r === 'me' ? 'user' : 'model', parts: [{ text: x.c }] }));
  contents[contents.length - 1].parts.push(...images.map(i => ({ inlineData: { mimeType: i.mime, data: i.data } })));
  const b = { systemInstruction: { parts: [{ text: SYS }] }, contents };
  if (deep && C.thinking) b.generationConfig = { thinkingConfig: C.thinking };
  const r = await gfetch(`/models/${model}:streamGenerateContent?alt=sse`, { method: 'POST', body: JSON.stringify(b) });
  if (!r.ok) throw new Error('chat ' + r.status + ' ' + (await r.text()).slice(0, 300));
  for await (const d of sse(r)) for (const p of (JSON.parse(d).candidates?.[0]?.content?.parts || [])) if (p.text && !p.thought) yield p.text;
}
async function chatOnce(prompt) { let s = ''; for await (const t of chatStream([{ r: 'me', c: prompt }], [], false)) s += t; return s; }

/* ---------- IMAGE generate / edit ---------- */
async function genImage({ prompt, image, mode }) {
  if (!prompt) throw new Error('Prompt khali hai');
  if (C.img === 'openai') {
    const h = { Authorization: 'Bearer ' + C.oaKey }; let r;
    if (mode === 'edit' && image) {
      const fd = new FormData(); fd.append('model', C.imgModel); fd.append('prompt', prompt);
      fd.append('image', new Blob([Buffer.from(image.data, 'base64')], { type: image.mime }), 'image.png');
      r = await fetch(C.oaBase + '/images/edits', { method: 'POST', headers: h, body: fd });
    } else r = await fetch(C.oaBase + '/images/generations', { method: 'POST', headers: { ...h, 'Content-Type': 'application/json' }, body: JSON.stringify({ model: C.imgModel, prompt, n: 1 }) });
    const j = await rj(r); if (!r.ok) throw new Error(j.error?.message || 'image ' + r.status);
    const d = j.data?.[0]; if (!d) throw new Error('Tasveer nahi mili');
    return d.b64_json ? 'data:image/png;base64,' + d.b64_json : d.url;
  }
  const parts = [{ text: mode === 'edit' ? 'Edit this image. Keep the original composition, faces, pose, text and layout exactly the same; change only what is requested: ' + prompt : prompt }];
  if (image) parts.push({ inlineData: { mimeType: image.mime, data: image.data } });
  const r = await gfetch(`/models/${C.imgModel}:generateContent`, { method: 'POST', body: JSON.stringify({ contents: [{ parts }] }) });
  const j = await rj(r); if (!r.ok) throw new Error(j.error?.message || 'image ' + r.status);
  const ps = j.candidates?.[0]?.content?.parts || [];
  const p = ps.find(x => x.inlineData || x.inline_data);
  if (!p) throw new Error(ps.map(x => x.text).filter(Boolean).join(' ') || 'Model ne tasveer nahi di (safety filter ho sakta hai).');
  const d = p.inlineData || p.inline_data;
  return `data:${d.mimeType || d.mime_type};base64,${d.data}`;
}

/* ---------- VIDEO generate (scene-by-scene, koi hadd nahi) ---------- */
const jobs = new Map();
async function runJob(job, { prompt, seconds, image }) {
  try {
    const N = Math.min(C.maxScenes, Math.max(1, Math.ceil(seconds / C.sceneSec))); job.total = N;
    let style = '', scenes = [prompt];
    if (N > 1) {
      job.note = 'kahani ke scenes likh raha hoon';
      try {
        const t = await chatOnce(`Plan a ${N}-scene video (each ${C.sceneSec} seconds) for: "${prompt.replace(/"/g, "'")}". Reply ONLY with JSON: {"style":"one sentence describing the characters, setting, look and lighting that must stay identical in every scene","scenes":["action of scene 1","..."]} with exactly ${N} scenes in story order.`);
        const j = cleanJSON(t); style = j.style || ''; scenes = (j.scenes || []).slice(0, N);
      } catch {}
      while (scenes.length < N) scenes.push(`${prompt} (part ${scenes.length + 1} of ${N})`);
    }
    const dir = path.join(DIR, job.id); fs.mkdirSync(dir, { recursive: true }); const files = [];
    for (let i = 0; i < N; i++) {
      if (job.cancelled) { job.state = 'cancelled'; return; }
      job.scene = i + 1; job.note = 'video ban rahi hai';
      const p = (style ? style + ' ' : '') + (N > 1 ? `Scene ${i + 1} of ${N}: ` : '') + scenes[i];
      const inst = { prompt: p }; if (i === 0 && image) inst.image = { bytesBase64Encoded: image.data, mimeType: image.mime };
      const r = await gfetch(`/models/${C.vidModel}:predictLongRunning`, { method: 'POST', body: JSON.stringify({ instances: [inst] }) });
      let op = await rj(r); if (!r.ok) throw new Error(op.error?.message || 'video start ' + r.status);
      const name = op.name, t0 = Date.now();
      while (!op.done) {
        if (job.cancelled) { job.state = 'cancelled'; return; }
        if (Date.now() - t0 > 15 * 60e3) throw new Error('Scene ' + (i + 1) + ' bohat der le gaya.');
        await sleep(8000); op = await rj(await gfetch('/' + name));
      }
      if (op.error) throw new Error(op.error.message || 'video error');
      const resp = op.response || {};
      const smp = resp.generateVideoResponse?.generatedSamples?.[0] || resp.generatedVideos?.[0];
      const uri = smp?.video?.uri;
      if (!uri) throw new Error(resp.generateVideoResponse?.raiMediaFilteredReasons?.[0] || 'Scene ban nahi saki (safety filter ho sakta hai).');
      const v = await fetch(uri, { headers: { 'x-goog-api-key': C.gKey }, redirect: 'follow' });
      if (!v.ok) throw new Error('video download ' + v.status);
      const f = path.join(dir, `s${String(i + 1).padStart(3, '0')}.mp4`); fs.writeFileSync(f, Buffer.from(await v.arrayBuffer())); files.push(f);
    }
    job.clips = files.map(f => `/api/video/file/${job.id}/${path.basename(f)}`);
    if (files.length === 1) job.url = job.clips[0];
    else if (HAS_FF) {
      job.note = 'scenes jor raha hoon';
      fs.writeFileSync(path.join(dir, 'list.txt'), files.map(f => `file '${f.replace(/'/g, "'\\''")}'`).join('\n'));
      if (await ff(['-y', '-f', 'concat', '-safe', '0', '-i', path.join(dir, 'list.txt'), '-c', 'copy', path.join(dir, 'final.mp4')])) job.url = `/api/video/file/${job.id}/final.mp4`;
    }
    job.state = 'done';
  } catch (e) { job.state = 'error'; job.error = e.message; }
}

/* ---------- VIDEO EDIT (ffmpeg, mehfooz whitelist) ---------- */
async function vedit({ prompt, video }) {
  if (!HAS_FF) throw new Error('Server par ffmpeg install nahi hai.');
  if (!video?.data) throw new Error('Video nahi mili');
  let o; try { o = cleanJSON(await chatOnce(`The user wants to edit a video. Reply ONLY with JSON {"op":"trim|speed|mute|gray|resize|audio","start":seconds,"end":seconds,"factor":0.5-2,"width":pixels} choosing the single op that best matches this request: "${String(prompt).replace(/"/g, "'")}"`)); }
  catch { throw new Error('Samajh nahi aya ke kya edit karna hai.'); }
  const id = crypto.randomUUID(), dir = path.join(DIR, id); fs.mkdirSync(dir);
  const inp = path.join(dir, 'in.mp4'), out = path.join(dir, o.op === 'audio' ? 'out.mp3' : 'out.mp4');
  fs.writeFileSync(inp, Buffer.from(video.data, 'base64'));
  const n = (x, d, lo, hi) => Math.min(hi, Math.max(lo, Number.isFinite(+x) ? +x : d));
  let a;
  if (o.op === 'trim') { const s = n(o.start, 0, 0, 86400), e = n(o.end, s + 10, s + 0.1, 86400); a = ['-ss', s, '-to', e, '-i', inp, '-c:v', 'libx264', '-c:a', 'aac']; }
  else if (o.op === 'speed') { const f = n(o.factor, 1, 0.5, 2); a = ['-i', inp, '-vf', `setpts=${1 / f}*PTS`, '-af', `atempo=${f}`]; }
  else if (o.op === 'mute') a = ['-i', inp, '-c:v', 'copy', '-an'];
  else if (o.op === 'gray') a = ['-i', inp, '-vf', 'hue=s=0', '-c:a', 'copy'];
  else if (o.op === 'resize') a = ['-i', inp, '-vf', `scale=${Math.round(n(o.width, 720, 120, 3840) / 2) * 2}:-2`, '-c:a', 'copy'];
  else if (o.op === 'audio') a = ['-i', inp, '-vn', '-q:a', '2'];
  else throw new Error('Yeh edit abhi support nahi (trim, speed, mute, gray, resize, audio).');
  if (!(await ff(['-y', ...a.map(String), out]))) throw new Error('ffmpeg edit nakam raha.');
  return { url: `/api/video/file/${id}/${path.basename(out)}`, op: o.op };
}

function serveFile(req, res, id, name) {
  if (name.includes('..')) return send(res, 400, { error: 'bad' });
  const f = path.join(DIR, id, name);
  if (!fs.existsSync(f) || !fs.statSync(f).isFile()) return send(res, 404, { error: 'file nahi mili' });
  const st = fs.statSync(f), type = name.endsWith('.mp3') ? 'audio/mpeg' : 'video/mp4';
  const m = (req.headers.range || '').match(/bytes=(\d*)-(\d*)/); let s = 0, e = st.size - 1, code = 200;
  if (m) { s = m[1] ? +m[1] : 0; e = m[2] ? Math.min(+m[2], e) : e; code = 206; }
  res.writeHead(code, { 'Content-Type': type, 'Accept-Ranges': 'bytes', 'Content-Length': e - s + 1, ...(code === 206 ? { 'Content-Range': `bytes ${s}-${e}/${st.size}` } : {}) });
  fs.createReadStream(f, { start: s, end: e }).pipe(res);
}

http.createServer(async (req, res) => {
  try {
    const p = new URL(req.url, 'http://x').pathname, POST = req.method === 'POST'; let m;
    if (req.method === 'GET' && (p === '/' || p === '/index.html')) { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); return res.end(fs.readFileSync(path.join(__dirname, 'public', 'index.html'))); }
    if (req.method === 'GET' && (m = p.match(/^\/api\/video\/file\/([\w-]+)\/([\w.-]+)$/))) return serveFile(req, res, m[1], m[2]); // id anjaan UUID hai
    if (!p.startsWith('/api/')) return send(res, 404, { error: '404' });
    if (C.token && req.headers['x-token'] !== C.token) return send(res, 401, { error: 'token chahiye' });
    if (p === '/api/health') return send(res, 200, { chat: C.chat, image: C.img, key: !!(C.gKey || C.oaKey), ffmpeg: HAS_FF, sceneSeconds: C.sceneSec });
    if (POST && p === '/api/chat') {
      const b = await readBody(req, 30e6);
      res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-cache', 'X-Accel-Buffering': 'no' });
      try { for await (const t of chatStream(b.messages || [], b.images || [], !!b.deep)) res.write(t); } catch (e) { res.write('\n\n[Error] ' + e.message); }
      return res.end();
    }
    if (POST && p === '/api/image') { const b = await readBody(req, 30e6); return send(res, 200, { url: await genImage(b) }); }
    if (POST && p === '/api/vedit') { const b = await readBody(req, 250e6); return send(res, 200, await vedit(b)); }
    if (POST && p === '/api/video/start') {
      const b = await readBody(req, 30e6);
      if ([...jobs.values()].filter(j => j.state === 'running').length >= C.maxJobs) return send(res, 429, { error: 'Pehle se bohat videos ban rahi hain, thori der baad try karein.' });
      const job = { id: crypto.randomUUID(), state: 'running', scene: 0, total: 0, note: 'shuru' }; jobs.set(job.id, job);
      runJob(job, { prompt: String(b.prompt || ''), seconds: Math.max(1, +b.seconds || C.sceneSec), image: b.image || null });
      return send(res, 200, { id: job.id });
    }
    if ((m = p.match(/^\/api\/video\/(status|cancel)\/([\w-]+)$/))) {
      const j = jobs.get(m[2]); if (!j) return send(res, 404, { error: 'job nahi mila' });
      if (m[1] === 'cancel') { j.cancelled = true; return send(res, 200, { ok: true }); }
      return send(res, 200, { state: j.state, scene: j.scene, total: j.total, note: j.note, url: j.url || null, clips: j.clips || [], error: j.error || null });
    }
    send(res, 404, { error: 'nahi mila' });
  } catch (e) { if (!res.headersSent) send(res, 500, { error: e.message }); else res.end(); }
}).listen(C.port, () => {
  console.log(`Tutor AI chal raha hai: http://localhost:${C.port}`);
  if (!C.gKey && !C.oaKey) console.log('WARNING: .env mein API key nahi mili.');
  if (!HAS_FF) console.log('NOTE: ffmpeg nahi mila — lambi video ke scenes jorna aur video editing band rahegi.');
  if (!C.token) console.log('NOTE: ACCESS_TOKEN set nahi — internet par chalane se pehle zaroor set karein.');
});
