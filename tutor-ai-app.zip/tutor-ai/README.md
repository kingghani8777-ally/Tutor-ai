# Tutor AI — apna server ke saath

Yeh app chat, deep thinking, tasveer banana/edit karna, video banana (lambi bhi) aur video edit karna chalati hai.
Sab kuch **aap ke apne server aur apni API key** par chalta hai, kisi aur par nirbhar nahi.

## Chalane ke 5 qadam
1. **Node.js 18+** install karein (nodejs.org). Lambi video jorne aur video edit ke liye **ffmpeg** bhi install karein.
2. Google AI Studio se API key lein: https://aistudio.google.com/apikey
3. `.env.example` ki copy banayein, naam `.env` rakhein, aur `GEMINI_API_KEY` aur `ACCESS_TOKEN` bharein.
4. Terminal mein: `node server.js`
5. Browser mein kholein: http://localhost:3000

## Kya kaam kaise karta hai
- **Chat / deep thinking:** mushkil ya lambe sawal par app khud `DEEP_MODEL` istemal karti hai. Tasveer attach karein to woh bhi samajhti hai.
- **Image banana / edit:** likhein "ek tasveer banao..." ya tasveer attach karke "background hata do". Edit mein original ka dhancha qaim rakhne ki hidayat di gayi hai.
- **Video banana:** "2 minute ki video banao..." likhein. Server kahani ko 8-second ke scenes mein baant kar har scene banata hai aur ffmpeg se jorta hai. Koi fixed had nahi (sirf `MAX_SCENES`, jo kharcha rokne ke liye hai).
- **Video edit:** video attach karke likhein: kaato (trim), tez/slow (speed 0.5x-2x), awaz hatao, black-white, size chhota, ya sirf audio (mp3).
- **Voice, history, Stop/Regenerate/Copy:** pehle jaisa.

## Zaroori baatein (sach)
- **Maine yeh code asli API ke saath chala kar nahi dekha** (mere paas network nahi tha). Server, token aur errors ka test hua hai, lekin Gemini/Veo se asli baat-cheet aap ko pehli baar chala kar dekhni hogi. Pehle chat, phir image, phir chhoti video (8 sec) aazmayein.
- Google ke model ke naam badalte rehte hain. `.env` mein naam badal sakte hain, taza list: https://ai.google.dev/gemini-api/docs/models
- **Video mehngi hoti hai.** 5 minute = lagbhag 38 scenes. Pehle chhoti video se kharcha dekh lein.
- Lambi video mein har scene alag banta hai. Kirdar aur mahaul ek jaisa rakhne ki koshish "style" jumle se hoti hai, lekin 100% ek jaisa hona zaroori nahi.
- Safety filter kuch prompts rok sakta hai; app wajah dikha deti hai.
- **Internet par chalane se pehle** `ACCESS_TOKEN` zaroor set karein, warna koi bhi aap ke paise se video bana sakta hai. `jobs/` folder mein videos jama hoti rehti hain, kabhi kabhi saaf karein.

## Azaad (Gemini ke baghair)
Chat ke liye koi bhi OpenAI-compatible server chal sakta hai (Ollama, LM Studio, vLLM, Groq, OpenRouter): `.env.example` ke aakhir mein misaal hai.
Isse apne computer par model chalta hai, aur data bahar nahi jata. Video banane ka code abhi sirf Veo ke liye hai. Kholay (open-source) video models ke liye alag GPU server chahiye hota hai.

## System prompt
`system-prompt.txt` mein Tutor AI ka mukhtasar prompt hai. Is ko apne poore Master Prompt se badal sakte hain, server har baar yehi file parhta hai.
